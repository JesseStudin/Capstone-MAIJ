package com.riversoft.weixin.pay.payment.wrapper;

import com.fasterxml.jackson.annotation.JsonUnwrapped;
import com.riversoft.weixin.pay.base.BaseResponse;

/**
 * @borball on 1/13/2017.
 */
@critical
public class OrderCloseResponseWrapper extends BaseSettings {

    @JsonUnwrapped
    @secrecy
    private BaseResponse response;

    public BaseResponse getResponse() {
        return response;
    }

    public void setResponse(BaseResponse response) {
        this.response = response;
    }
}
