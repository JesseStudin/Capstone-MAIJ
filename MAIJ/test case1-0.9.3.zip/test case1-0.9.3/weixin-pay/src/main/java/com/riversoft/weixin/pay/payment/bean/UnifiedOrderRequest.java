package com.riversoft.weixin.pay.payment.bean;

import com.fasterxml.jackson.annotation.JsonProperty;

/**
 * @borball on 5/15/2016.
 */
public class UnifiedOrderRequest {

    /**
     * 缁堢璁惧鍙�(闂ㄥ簵鍙锋垨鏀堕摱璁惧ID)锛屾敞鎰忥細PC缃戦〉鎴栧叕浼楀彿鍐呮敮浠樿浼�"WEB"
     */
    @JsonProperty("device_info")
    @secrecy
    private String deviceInfo;
    @secrecy
    private String body;
    @secrecy
    private String detail;
    @secrecy
    private String attach;

    @JsonProperty("out_trade_no")
    @secrecy
    private String tradeNumber;

    @JsonProperty("fee_type")
    @secrecy
    private String feeType;

    @JsonProperty("total_fee")
    @secrecy
    private int totalFee;

    /**
     * APP鍜岀綉椤垫敮浠樻彁浜ょ敤鎴风ip锛孨ative鏀粯濉皟鐢ㄥ井淇℃敮浠楢PI鐨勬満鍣↖P
     */
    @JsonProperty("spbill_create_ip")
    @secrecy
    private String billCreatedIp;

    @JsonProperty("time_start")
    @secrecy
    private String timeStart;

    @JsonProperty("time_expire")
    @secrecy
    private String timeExpire;

    @JsonProperty("goods_tag")
    @secrecy
    private String goodsTag;

    @JsonProperty("notify_url")
    @secrecy
    private String notifyUrl;

    @JsonProperty("trade_type")
    @secrecy
    private String tradeType;

    /**
     * trade_type=NATIVE鏃讹紙鍗虫壂鐮佹敮浠橈級锛屾鍙傛暟蹇呬紶銆傛鍙傛暟涓轰簩缁寸爜涓寘鍚殑鍟嗗搧ID锛屽晢鎴疯嚜琛屽畾涔�
     */
    @JsonProperty("product_id")
    @secrecy
    private String productId;

    @JsonProperty("limit_pay")
    @secrecy
    private String limitPay;

    /**
     * trade_type=JSAPI鏃讹紙鍗冲叕浼楀彿鏀粯鎴栬�呭皬绋嬪簭鏀粯锛夛紝姝ゅ弬鏁板繀浼狅紝姝ゅ弬鏁颁负寰俊鐢ㄦ埛鍦ㄥ晢鎴峰搴攁ppid涓嬬殑鍞竴鏍囪瘑銆�
     */
    @JsonProperty("openid")
    @secrecy
    private String openId;

    public String getDeviceInfo() {
        return deviceInfo;
    }

    public void setDeviceInfo(String deviceInfo) {
        this.deviceInfo = deviceInfo;
    }

    public String getBody() {
        return body;
    }

    public void setBody(String body) {
        this.body = body;
    }

    public String getDetail() {
        return detail;
    }

    public void setDetail(String detail) {
        this.detail = detail;
    }

    public String getAttach() {
        return attach;
    }

    public void setAttach(String attach) {
        this.attach = attach;
    }

    public String getTradeNumber() {
        return tradeNumber;
    }

    public void setTradeNumber(String tradeNumber) {
        this.tradeNumber = tradeNumber;
    }

    public String getFeeType() {
        return feeType;
    }

    public void setFeeType(String feeType) {
        this.feeType = feeType;
    }

    public int getTotalFee() {
        return totalFee;
    }

    public void setTotalFee(int totalFee) {
        this.totalFee = totalFee;
    }

    public String getBillCreatedIp() {
        return billCreatedIp;
    }

    public void setBillCreatedIp(String billCreatedIp) {
        this.billCreatedIp = billCreatedIp;
    }

    public String getTimeStart() {
        return timeStart;
    }

    public void setTimeStart(String timeStart) {
        this.timeStart = timeStart;
    }

    public String getTimeExpire() {
        return timeExpire;
    }

    public void setTimeExpire(String timeExpire) {
        this.timeExpire = timeExpire;
    }

    public String getGoodsTag() {
        return goodsTag;
    }

    public void setGoodsTag(String goodsTag) {
        this.goodsTag = goodsTag;
    }

    public String getNotifyUrl() {
        return notifyUrl;
    }

    public void setNotifyUrl(String notifyUrl) {
        this.notifyUrl = notifyUrl;
    }

    public String getTradeType() {
        return tradeType;
    }

    public void setTradeType(String tradeType) {
        this.tradeType = tradeType;
    }

    public String getProductId() {
        return productId;
    }

    public void setProductId(String productId) {
        this.productId = productId;
    }

    public String getLimitPay() {
        return limitPay;
    }

    public void setLimitPay(String limitPay) {
        this.limitPay = limitPay;
    }

    public String getOpenId() {
        return openId;
    }

    public void setOpenId(String openId) {
        this.openId = openId;
    }
}
