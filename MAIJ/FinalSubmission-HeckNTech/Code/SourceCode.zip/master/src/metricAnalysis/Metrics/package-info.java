/**
 * 
 */
/**
 * For holding the metric classes
 * @author Jacob Botha
 *
 */
package metricAnalysis.Metrics;