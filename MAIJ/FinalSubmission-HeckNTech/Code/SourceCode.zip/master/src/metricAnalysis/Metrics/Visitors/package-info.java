/**
 * 
 */
/**package to hold visitors used for calculating metric values
 * @author Jacob Botha
 *
 */
package metricAnalysis.Metrics.Visitors;