/**
 * 
 */
/**
 * Package to contain the code to do with selecting and running the metric
 * analysis on the code.
 * 
 * @author Jacob Botha
 *
 */
package metricAnalysis;