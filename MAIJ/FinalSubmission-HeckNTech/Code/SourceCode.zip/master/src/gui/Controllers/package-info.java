/**
 * 
 */
/**The controllers for the GUI components described by the fxml douments in the gui package.
 * @author Jacob Botha
 *
 */
package gui.Controllers;