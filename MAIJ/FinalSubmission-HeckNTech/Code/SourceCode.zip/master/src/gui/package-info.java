/**
 * 
 */
/**Containts the gui used to interact with the rest of the program
 * @author Jacob Botha
 *
 */
package gui;